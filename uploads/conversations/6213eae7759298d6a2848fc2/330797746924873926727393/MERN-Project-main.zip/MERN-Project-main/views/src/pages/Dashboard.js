import React from 'react';

const Dashboard = () => {
  return ( 
    <div>
      Hello depuis le dashboard
    </div>
   );
}

export default Dashboard;