import React from 'react';
import LoaderAnim from '../components/tools/Loader';

const Loader = () => {
    return (
      <LoaderAnim />
    )
}

export default Loader;