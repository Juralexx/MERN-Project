import React from 'react';

const Project = () => {
  return ( 
    <div>
      Hello depuis la page project
    </div>
   );
}

export default Project;