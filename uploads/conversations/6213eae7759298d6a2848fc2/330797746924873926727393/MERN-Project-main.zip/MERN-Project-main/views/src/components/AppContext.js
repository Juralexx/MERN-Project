import { createContext } from "react";

export const UidContext = createContext()