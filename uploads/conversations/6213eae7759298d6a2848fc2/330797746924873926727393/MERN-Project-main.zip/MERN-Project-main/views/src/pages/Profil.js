import React from 'react';
import Profil from '../components/Profil/Profil';

const ProfilPage = () => {
    return (
      <Profil />
    )
}

export default ProfilPage;