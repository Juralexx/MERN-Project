import React from 'react';

const Trending = () => {
  return ( 
    <div>
      Hello depuis les projects du moment en tendance
    </div>
   );
}

export default Trending;